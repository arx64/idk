<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2/dist/tailwind.min.css" rel="stylesheet" type="text/css" />
    <link href="https://cdn.jsdelivr.net/npm/daisyui@1.14.2/dist/full.css" rel="stylesheet" type="text/css" />

</head>
<body>
    <form action="cek_user.php" method="POST">
    <div class="card shadow-2xl lg:card-side bg-primary text-primary-content">
    <div class="card-body">   
    <div class="form-control">
  <label class="label">
    <span class="label-text">Username</span>
  </label> 
  <input type="text" placeholder="Input your username..." class="input input-bordered">
</div> 
<div class="form-control">
  <label class="label">
    <span class="label-text">Password</span>
  </label> 
  <input type="password" placeholder="Input your password..." class="input input-bordered">
  <br>
  <button class="btn btn-accent btn-active" role="button" aria-pressed="true">Login</button> 

</div>
</div>
</div>
</div> 
</body>
</html>