<?php
include 'koneksi.php';
session_start();
header("Authorization: Basic ".sha1(date("D-m-Y"))."");
$method = $_SERVER["REQUEST_METHOD"];
if ($method == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $query = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
    $sql = mysqli_query($dbc, $query);
    $n1 = mysqli_num_rows($sql);
    $success = array('status' => '200', 'auth_token' => md5($password));
    $fail = array('status' => '401', 'message' => 'invalid authentication!');
    $sukses = json_encode($success);
    $gagal = json_encode($fail);
    if ($n1 == 0) {
    echo $gagal;
} elseif ($n1 == 1) {
    echo $sukses;
    $_SESSION["username"] = $username;
    header("Authorization: Basic ".base64_encode($_SESSION["username"])."");
}
} else {
    echo "Method $method Not Supported!";
}