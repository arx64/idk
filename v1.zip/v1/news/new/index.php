<?php
error_reporting(0);
include 'koneksi.php';
session_start();
$judul = $_POST["judul"];
$kategori = $_POST["kategori"];
$konten = $_POST["konten"];
$poster = $_POST["poster"];
header("Authorization: Basic ".base64_encode($_SESSION["username"])."");
$method = $_SERVER["REQUEST_METHOD"];
$succ = array('status' => '200', 'message' => 'new added successfully');
$fail = array('status' => '401', 'message' => 'invalid authentication');
$empty = array('status' => '401', 'message' => 'Data Is Emtpy!');
$sukses = json_encode($succ);
$gagal = json_encode($fail);
$kosong = json_encode($empty);
if ($method == "POST") {
    if (!empty($_SESSION)) {
$q = "INSERT INTO `db_index` (`judul`, `kategori`, `konten`, `poster`) VALUES ('$judul', '$kategori', '$konten', '$poster');";
$res = mysqli_query($dbc, $q);
if ($res) {
    echo $sukses;
    print_r($_SESSION);
}   else {
    echo $gagal;
}
} else {
    echo $gagal;
}
} else {
    echo "Method $method Not Supported!";
}