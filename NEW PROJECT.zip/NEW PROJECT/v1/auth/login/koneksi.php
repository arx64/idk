<?php
$db = "smkn1tm_db";
$username = "root";
$pass = "";
$host = "localhost";

$dbc = mysqli_connect($host, $username, $pass, $db) or die("Can't Connect To Database!".mysql_error());