<?php
error_reporting(0);
include 'koneksi.php';
session_start();
header("Authorization: Basic ".base64_encode($_SESSION["username"])."");
$method = $_SERVER["REQUEST_METHOD"];
$succ = array('status' => '200', 'message' => 'logout success');
$fail = array('status' => '401', 'message' => 'unauthorized user');
$sukses = json_encode($succ);
$gagal = json_encode($fail);
if ($method == "POST" && (!empty($_SESSION["username"]))) {
    session_start();
    session_destroy();
    echo $sukses;
} else {
    echo $gagal;
}