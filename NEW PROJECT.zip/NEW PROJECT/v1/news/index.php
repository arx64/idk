<?php
error_reporting(0);
include 'koneksi.php';
session_start();
$method = $_SERVER['REQUEST_METHOD'];
$id = $_GET["id"];
$judul = $_GET["judul"];
$kategori = $_GET["kategori"];
$konten = $_GET["konten"];
$poster = $_GET["poster"];

header("Authorization: Basic ".base64_encode($_SESSION["username"])."");
$method = $_SERVER["REQUEST_METHOD"];
$succ = array('status' => '200', 'message' => 'new updated successfully');
$failauth = array('status' => '401', 'message' => 'unauthorized user');
$fail = array('status' => '422', 'message' => 'cannot be proceed');
$sukses = json_encode($succ);
$gagal = json_encode($fail);
$failau = json_encode($failauth);
if ($method == "PUT") {
     $data = file_get_contents('php://input'); 
     $d = fopen("php://input", "r");
     // {"judul": "asasasas", "kategori": "11212katewe", "konten": "12131", "poster": "12ds"}
     // $arrayName = array('judul' => 'asas', 'kategori' => 'asaasas', 'konten' => 'asaasas', 'poster' => 'asaasas');
     // echo json_decode($arrayName, true);
     echo $d;
    if (empty($_SESSION)) {
$q = "UPDATE `db_index` SET `judul` = '$judul', `kategori` = '$kategori', `konten` = '$konten', `poster` = '$poster' WHERE `db_index`.`id` = $id";
$res = mysqli_query($dbc, $q);
print_r($res);
if ($res) {
    echo $sukses;
}   else {
    echo $gagal;
}
} else {
    echo $failau;
}
} else {
    echo "Method $method Not Supported!";
}